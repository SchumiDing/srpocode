
from typing import Callable, List, Optional, Tuple, Dict, Any
import logging
import re
import torch
import torch.nn.functional as F
from verl.workers.reward_manager import register
import requests
import time
import torch
from transformers import AutoModel, AutoTokenizer
import torch.nn.functional as F
endpoint = "http://10.140.37.4:5000/v1/step_rewards"
logger = logging.getLogger(__name__)
proxies = {
    "http": None,
    "https": None
}
from openai import OpenAI
import json
import multiprocessing as mp
from sympy import simplify, parse_expr
from sympy.parsing.latex import parse_latex
client = OpenAI(api_key="sk-ce18ce62795d4af6866c9af5ebac02d4", base_url="https://api.deepseek.com")
def if_same(y_hat, y):
    prompt = "Please judge if the following two mathematical expression refers to the same result, and please ignore syntax errors:"+\
        f"y_hat: {y_hat}"+ "\n" +\
        f"y: {y}"+ "\n" +\
        "Please only return a json with key 'answer' and value True or False\n **Notice** Make sure you only return a json, no other text or comments."
    answer = None
    while True:
        try:
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[{"role": "user", "content": prompt}],
                stream=False
            )
            resp = response.choices[0].message.content.strip()
            resp = resp.replace("```json", "").replace("```", "")
            answer = json.loads(resp)['answer']
            break
        except:
            print(resp, flush=True)
            print("Error in if_same", flush=True)
            continue
    return answer


def entropy_segmentation(entropies: torch.Tensor, start_idx: int, outLength: int, max_branches: int = 5, min_gap: int = 10) -> List[Tuple[int, int]]:
    """
    根据 entropies 对序列分段，返回一组 (start, end) 区间，end 不包含（闭开区间 [start, end)）。
    原始逻辑基础上修正边界问题并保证至少返回一个 segment 覆盖整个序列。

    Args:
        entropies: 1D tensor, length T
        max_branches: 最大候选 anchors 数量（选择 top-k 高 entropy 位点作为 anchor）
        min_gap: 两个 anchor 之间最小距离，同时要求 anchor 离序列边缘至少 min_gap，用以避免过短 segment

    Returns:
        List[(start, end)] covering [0, T)
    """
    if outLength-start_idx < max_branches+1:
        return [(start_idx, outLength)]
    # 从 start_idx 开始，找到 max_branches 个 anchor， 去除间距小于 min_gap 的 anchor
    topk_idx = torch.topk(entropies[start_idx:outLength], k=max_branches).indices
    topk_id = topk_idx + start_idx
    topk_id = sorted(topk_id)
    topk_idx = []
    n = outLength
    for i in range(len(topk_id)-1):
        j = i+1
        if topk_id[j] - topk_id[i] > min_gap:
            topk_idx.append(topk_id[i])
        else:
            while j<len(topk_id) and topk_id[j] - topk_id[i] <= min_gap:
                j += 1
            i = j
            if i < len(topk_id):
                topk_idx.append(topk_id[i])
    cuts = []
    last_cut = start_idx
    # 将每个 anchor 视为 cut 点（点到点之间形成 segments）
    for a in topk_idx:
        if a - last_cut >= min_gap:
            # 为保证 segment 能分割出区间，cut 记录 anchor 本身
            cuts.append(a)
            last_cut = a
    # 构建 segments，由于 cuts 是 anchor positions (单点)，构建区间 [prev_cut, curr_cut)
    segments: List[Tuple[int, int]] = []
    if len(cuts) == 0:
        segments = [(0, n)]
    else:
        prev = 0
        for c in cuts:
            # 保证边界合法
            segments.append((prev, c))
            prev = c
        # 最后一段从最后 anchor 到结尾
        if prev < n:
            segments.append((prev, n))

    sanitized: List[Tuple[int, int]] = []
    cur = 0
    for (s, e) in segments:
        s = max(0, min(n, int(s)))
        e = max(0, min(n, int(e)))
        if e <= s:
            continue
        if s > cur:
            # 在 s 与 cur 之间存在间隙，填补
            sanitized.append((cur, s))
        sanitized.append((s, e))
        cur = e
    if cur < n:
        sanitized.append((cur, n))

    if len(sanitized) == 0:
        return [(0, n)]
    return sanitized
def parse_llama3_conversation(text: str) -> Tuple[Optional[str], Optional[str]]:
    pattern = r'<\|start_header_id\|>([^<]+)<\|end_header_id\|>\s*\n{0,2}(.*?)\s*<\|eot_id\|>'
    
    matches = re.findall(pattern, text, re.DOTALL)
    
    system_content = None
    user_content = None
    
    for role, content in matches:
        role = role.strip()
        content = content.strip()
        
        if role == "system" and system_content is None:
            system_content = content
        elif role == "user" and user_content is None:
            user_content = content
    
    return (system_content, user_content)
def compare_latex_expressions(expr1: str, expr2: str) -> bool:
    try:
        def normalize(expr):
            expr = re.sub(r'\s+', '', expr)
            return expr.replace(' ', '')
        
        if normalize(expr1) == normalize(expr2):
            return True
        
        try:
            sympy1 = parse_latex(expr1)
            sympy2 = parse_latex(expr2)
            return simplify(sympy1 - sympy2) == 0
        except:
            return False
            
    except Exception as e:
        return False
@register("srpo")
class NaiveRewardManager:
    def __init__(self,
                 tokenizer: Any,
                 num_examine: int,
                 compute_score,
                 reward_fn_key: str,
                 alpha: float = 0.5,
                 max_branches: int = 5,
                 min_gap: int = 10,
                 seg_comp_fn: Optional[Callable[[torch.Tensor, Dict[str, Any]], float]] = None,
                 rollout_comp_fn: Optional[Callable[[List[float], Dict[str, Any]], float]] = None):
        assert 0.0 <= alpha <= 1.0, "alpha must be in [0,1]"
        
        self.alpha = 1
        self.max_branches = int(max_branches)
        self.min_gap = int(min_gap)
        self.seg_comp_fn = seg_comp_fn
        self.rollout_comp_fn = rollout_comp_fn
        self.tokenizer = tokenizer
        self.scv=(torch.sqrt(1/48))

    def make_step_rewards(self,logits, token_masks):
        probabilities = F.softmax(logits, dim=-1)
        probabilities = probabilities * token_masks.unsqueeze(-1) # bs, seq_len, num_labels
        
        all_scores_res = []
        for i in range(probabilities.size(0)):
            sample = probabilities[i] # seq_len, num_labels
            positive_probs = sample[sample != 0].view(-1, 2)[:, 1] # valid_tokens, num_labels
            non_zero_elements_list = positive_probs.cpu().tolist()
            all_scores_res.append(non_zero_elements_list)
        return all_scores_res
    def process_request(self, messages):
        """处理推理请求"""
        # convs = []
        # for i in range(len(messages)):
        #     messages[i][-1]['content'] = "<extra_0>".join(messages[i][-1]['content'])+"<extra_0>"
        # # print(messages[-1]['content'], flush=True)
        #     conversation_str = self.mtokenizer.apply_chat_template(
        #         messages[i], 
        #         tokenize=False, 
        #         add_generation_prompt=False
        #     )

        #     convs.append(conversation_str)

        # # 批量处理所有对话
        # inputs = self.mtokenizer(
        #     convs, 
        #     padding=True, 
        #     truncation=True, 
        #     return_tensors="pt"
        # ).to(self.model.device)

        # outputs = self.model(**inputs)

        # step_sep_id = self.mtokenizer.encode("<extra_0>")[0]

        # token_masks = (inputs['input_ids'] == step_sep_id)
        # step_reward = self.make_step_rewards(outputs[0], token_masks)
        while True:
            try:
                response = requests.post(endpoint, json={"messages": messages}, proxies=proxies, timeout=60000)
                step_reward = response.json()['step_rewards']
                break
            except Exception as e:
                print(e, flush=True)
                time.sleep(10)
        return step_reward
    
    def _default_seg_comp(self, l, dat) -> float:
        """
        默认 segment reward：使用 -mean(log_prob) 作为示例（log_prob 越高，-mean 越低）
        如果输入为空或标量，返回 0.0。
        segment_slice: 1D tensor, 每个 time step 的 log_prob proxy（可能是负 entropy，也可能是 log_prob）
        """
        segment_rewards = torch.zeros(l)
        msgs = []
        for segment_slice, sys, usr in dat:
            if sys is None :
                message = [
                    {"role": "user", "content": usr},
                    {"role": "assistant", "content": [value for value in segment_slice.values()]}
                ]
            else:
                message = [
                    {"role": "system", "content": sys},
                    {"role": "user", "content": usr},
                    {"role": "assistant", "content": [value for value in segment_slice.values()]}
                ]
            msgs.append(message)
        step_rewards = self.process_request(msgs)
        segment_rewards = []
        for step_reward, segment_slice in zip(step_rewards, dat):
            segment_reward = torch.zeros(l) 
            for reward, rng in zip(step_reward, segment_slice[0].keys()):
                segment_reward[rng[0]:rng[1]] = reward
            segment_rewards.append(segment_reward)
        return segment_rewards
    @staticmethod
    def _default_rollout_comp(ground_truth: str, sequence: str) -> float:
        pattern = r'\\boxed\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        matches = re.findall(pattern, sequence)
        if len(matches) == 0:
            # if len(sequence) > 4000:
            #     return -1.0 - len(sequence)/1000
            return -1.0
        predicted_answer = matches[-1]
        
        if compare_latex_expressions(predicted_answer, ground_truth):
            # print(f"Right answer: \"{predicted_answer}\" == \"{ground_truth}\"", flush=True)
            return 1.0
        else:
            # print(f"Wrong answer: \"{predicted_answer}\" != \"{ground_truth}\"", flush=True)
            # print(sequence[-100:], flush=True)
            # if len(sequence) > 4000:
            #     return -1.0 - len(sequence)/1000
            return -1.0
        # if len(sequence) > 1000:
        #     value -= len(sequence)/1000

    def compute_for_rollout(self, input_ids,ground_truth, response_mask, rollout_outputs: List[str], entropys: torch.Tensor, repeat_times: int = 1) -> Dict[str, Any]:
        """
        主入口：对 rollout 中每个样本做 segmentation、seg reward、rollout reward、归一化与 final adv 计算。
        Args:
            rollout_outputs: list of sample dicts (任意结构，但常见包含 'log_probs'/'logits'/'actions'/'length' 等)
        Returns:
            dict with key 'per_sample' -> list of per-sample dicts (见文件头说明)
        """
        per_sample_info: List[Dict[str, Any]] = []
        if rollout_outputs is None:
            return {'per_sample': per_sample_info}

        # 第一遍：计算 segment 划分与原始 seg reward、rollout raw reward
        # for i in range(len(rollout_outputs)):
        #     print(
        #         "Response", self.tokenizer.decode(rollout_outputs[i]), flush=True
        #     )
        data = []
        seqRRs = []
        # print(entropys[0], flush=True)
        # print(entropys[0][-outLength:], flush=True)
        outl = 0
        
        rollout_args = []
        for i in range(len(rollout_outputs)):
            sample = rollout_outputs[i]
            sysusr = input_ids[i]
            stopidx = sum(response_mask[i])
            outLength = stopidx
            outl += outLength
            start_idx = 0
            # print("input", self.tokenizer.decode(sysusr), flush=True)
            sys, usr = parse_llama3_conversation(self.tokenizer.decode(sysusr))
            # print("sys", sys, flush=True)
            # print("usr", usr, flush=True)
            rollout_args.append((ground_truth[i], self.tokenizer.decode(sample[:outLength-1])))
            segments = entropy_segmentation(entropys[i], start_idx, outLength)
            segment_rewards_dict = {(s, e): self.tokenizer.decode(sample[s:e]) for s, e in segments}
            data.append((segment_rewards_dict, sys, usr))
            per_sample_info.append({
                'segments': segments,
                'T': len(entropys[i]),
                "l": sum(response_mask[i])
                })
        
        with mp.Pool(96) as pool:
            seqRRs = pool.starmap(self._default_rollout_comp, rollout_args)
        
        for i, seqRReward in enumerate(seqRRs):
            per_sample_info[i]['seq_reward'] = seqRReward
        
        segRs = self._default_seg_comp(len(entropys[0]), data)
        
        print(f"outl: {outl}", flush=True)
        # print(len(segRs), flush=True)
        print(len(per_sample_info), flush=True)
        for i in range(len(per_sample_info)):
            per_sample_info[i]['segment_rewards'] = segRs[i]

        # 第二步：样本内归一化（segment_norms）
        segment_norms = [info['segment_rewards'] for info in per_sample_info]
        # 删除mask的部分
        masked_segement_norms = []
        for i, row in enumerate(segment_norms):
            
            maskedLength = torch.sum(response_mask[i])
            masked_segement_norms.append(row[:maskedLength-1])
        onedim = torch.cat(masked_segement_norms, dim=-1)
        mean = float(onedim.mean().item())
        std = float(onedim.std().item())
        tau = std
        zscores = []
        for row in masked_segement_norms:
            epsilon = 1e-8
            if std > epsilon:
                zscores.append((row - mean) / (std + epsilon))
            else:
                zscores.append(torch.zeros(len(row)))
        for i, row in enumerate(segment_norms):
            T = per_sample_info[i]['T']
            maskedLength = torch.sum(response_mask[i])
            row[:maskedLength-1] = zscores[i]
        # for i, row in enumerate(segment_norms):
        #     print(row.shape, flush=True)
        segment_norms = torch.stack(segment_norms)
        # print(f"length: {len(per_sample_info)}")
        rollout_raw_reward = [info['seq_reward'] for info in per_sample_info]
        rewards_tensor = [info['segment_rewards'] for info in per_sample_info]
        rewards_tensor = torch.stack(rewards_tensor)
        # 第三步：rollout-level 归一化 -> beta
        for i in range(len(rollout_raw_reward)//repeat_times):
            # print(f"i: {i}")
            rollout_raw_rewards = rollout_raw_reward[(i)*repeat_times:(i+1)*repeat_times]
            mean = float(sum(rollout_raw_rewards) / len(rollout_raw_rewards))
            # mean = 0
            std = float(torch.std(torch.tensor(rollout_raw_rewards
                                               , dtype=torch.float32)))
            if std > epsilon:
                tz_scores = (torch.tensor(rollout_raw_rewards) - mean) / (std + epsilon)
            else:
                tz_scores = torch.zeros(len(rollout_raw_rewards))
            for j in range(i*repeat_times, (i+1)*repeat_times):
                per_sample_info[j]['beta'] = tz_scores.tolist()[j-i*repeat_times]
        # 第四步：构建 final advantages 并广播到时间步
        for idx, info in enumerate(per_sample_info):
            alphai = self.alpha * torch.exp(-tau/self.scv)
            seg_norms = segment_norms[idx]
            beta = info['beta']
            per_timestep_adv = seg_norms*(1-alphai) + beta * alphai
            info['per_timestep_adv'] = per_timestep_adv
            

        betaTensor = torch.tensor([info["seq_reward"] for info in per_sample_info], dtype=torch.float16)
        advTensor = torch.stack([info['per_timestep_adv'] for info in per_sample_info])
        return rewards_tensor, betaTensor, advTensor
    
    # def __call__(self, data: DataProto, config: Dict[str, Any]) -> Tuple[torch.Tensor, Dict[str, Any]]:
    #     return self.compute_for_rollout(data.batch)