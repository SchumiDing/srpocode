
from typing import Callable, List, Optional, Tuple, Dict, Any
import logging
import re
import torch
import torch.nn.functional as F
from verl.workers.reward_manager import register
import requests
import time
import torch
from transformers import AutoModel, AutoTokenizer
import torch.nn.functional as F
endpoint = "http://10.140.37.71:5000/v1/step_rewards"
logger = logging.getLogger(__name__)
proxies = {
    "http": None,
    "https": None
}
from sympy import simplify, parse_expr
from sympy.parsing.latex import parse_latex
import multiprocessing as mp
def parse_llama3_conversation(text: str) -> Tuple[Optional[str], Optional[str]]:
    pattern = r'<\|start_header_id\|>([^<]+)<\|end_header_id\|>\s*\n{0,2}(.*?)\s*<\|eot_id\|>'
    
    matches = re.findall(pattern, text, re.DOTALL)
    
    system_content = None
    user_content = None
    
    for role, content in matches:
        role = role.strip()
        content = content.strip()
        
        if role == "system" and system_content is None:
            system_content = content
        elif role == "user" and user_content is None:
            user_content = content
    
    return (system_content, user_content)
def compare_latex_expressions(expr1: str, expr2: str) -> bool:
    try:
        def normalize(expr):
            expr = re.sub(r'\s+', '', expr)
            return expr.replace(' ', '')
        
        if normalize(expr1) == normalize(expr2):
            return True
        
        try:
            sympy1 = parse_latex(expr1)
            sympy2 = parse_latex(expr2)
            return simplify(sympy1 - sympy2) == 0
        except:
            return False
            
    except Exception as e:
        return False
@register("grpo")
class GRPORewardManager:
    def __init__(self,
                 tokenizer: Any,
                 num_examine: int,
                 compute_score,
                 reward_fn_key: str,
                 alpha: float = 0.5,
                 max_branches: int = 5,
                 min_gap: int = 10,
                 seg_comp_fn: Optional[Callable[[torch.Tensor, Dict[str, Any]], float]] = None,
                 rollout_comp_fn: Optional[Callable[[List[float], Dict[str, Any]], float]] = None):
        assert 0.0 <= alpha <= 1.0, "alpha must be in [0,1]"
        self.alpha = float(alpha)
        self.max_branches = int(max_branches)
        self.min_gap = int(min_gap)
        self.seg_comp_fn = seg_comp_fn
        self.rollout_comp_fn = rollout_comp_fn
        self.tokenizer = tokenizer

    @staticmethod
    def _default_rollout_comp(ground_truth: str, sequence: str) -> float:
        pattern = r'\\boxed\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}'
        matches = re.findall(pattern, sequence)
        if len(matches) == 0:
            # if len(sequence) > 4000:
            #     return -1.0 - len(sequence)/1000
            return -1.0
        predicted_answer = matches[-1]
        
        if compare_latex_expressions(predicted_answer, ground_truth):
            return 1.0
        else:
            # if len(sequence) > 4000:
            #     return -1.0 - len(sequence)/1000
            return -1.0

    def compute_for_rollout(self, input_ids,ground_truth, response_mask, rollout_outputs: List[str], entropys: torch.Tensor, repeat_times: int = 1) -> Dict[str, Any]:
        """
        主入口：对 rollout 中每个样本做 segmentation、seg reward、rollout reward、归一化与 final adv 计算。
        Args:
            rollout_outputs: list of sample dicts (任意结构，但常见包含 'log_probs'/'logits'/'actions'/'length' 等)
        Returns:
            dict with key 'per_sample' -> list of per-sample dicts (见文件头说明)
        """
        per_sample_info: List[Dict[str, Any]] = []
        if rollout_outputs is None:
            return {'per_sample': per_sample_info}

        # 第一遍：计算 segment 划分与原始 seg reward、rollout raw reward
        raw_rewards: List[float] = []
        # for i in range(len(rollout_outputs)):
        #     print(
        #         "Response", self.tokenizer.decode(rollout_outputs[i]), flush=True
        #     )
        stoptoken = [self.tokenizer.encode(self.tokenizer.eos_token)[0]]
        data = []
        
        rollout_args = []
        for i in range(len(rollout_outputs)):
            sample = rollout_outputs[i]
            sysusr = input_ids[i]
            stopidx = sum(response_mask[i])
            outLength = stopidx
            start_idx = 0
            # print("input", self.tokenizer.decode(sysusr), flush=True)
            sys, usr = parse_llama3_conversation(self.tokenizer.decode(sysusr))
            # print("sys", sys, flush=True)
            # print("usr", usr, flush=True)
            rollout_args.append((ground_truth[i], self.tokenizer.decode(sample[:outLength-1])))
            # print(start_idx, outLength, flush=True)
        
        
            # segment_rewards = self._default_seg_comp(len(entropys[i]), segment_rewards_dict, sys, usr)
            per_sample_info.append({
                'T': len(entropys[i])
                })

        with mp.Pool(96) as pool:
            seqRewards = pool.starmap(self._default_rollout_comp, rollout_args)
        
        for i, seqReward in enumerate(seqRewards):
            per_sample_info[i]['seq_reward'] = seqReward

        rollout_raw_rewards = [info['seq_reward']+torch.zeros(len(entropys[i])) for info in per_sample_info]
        rollout_raw_rewards = torch.stack(rollout_raw_rewards)
        rollout_raw_reward = [info['seq_reward'] for info in per_sample_info]
        
        for i in range(len(rollout_raw_reward)//repeat_times):
            # print(f"i: {i}")
            rollout_reward = rollout_raw_reward[(i)*repeat_times:(i+1)*repeat_times]
            mean = float(sum(rollout_reward) / len(rollout_reward))
            std = float(torch.std(torch.tensor(rollout_reward
                                               , dtype=torch.float32)))
            if std != 0:
                tz_scores = (torch.tensor(rollout_reward) - mean) / std
            else:
                tz_scores = torch.zeros(len(rollout_reward))
            for j in range(i*repeat_times, (i+1)*repeat_times):
                if std == 0:
                    per_sample_info[j]['beta'] = 0
                else:
                    per_sample_info[j]['beta'] = tz_scores.tolist()[j-i*repeat_times]
        # 第四步：构建 final advantages 并广播到时间步
        for idx, info in enumerate(per_sample_info):
            
            beta = info['beta']
            per_timestep_adv = torch.zeros(len(entropys[idx]))+beta
            info['per_timestep_adv'] = per_timestep_adv
            

        betaTensor = torch.tensor([info['seq_reward'] for info in per_sample_info], dtype=torch.float16)
        advTensor = torch.stack([info['per_timestep_adv'] for info in per_sample_info])
        return rollout_raw_rewards, betaTensor, advTensor
    
    # def __call__(self, data: DataProto, config: Dict[str, Any]) -> Tuple[torch.Tensor, Dict[str, Any]]:
    #     return self.compute_for_rollout(data.batch)